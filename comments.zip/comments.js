//stores and displays comments, and lets users post comments
function CommentWidget(id, getCommentsURL, commentURL, replyURL, commentText) {
  //the div that contains the comment form and comments
  this.div = document.getElementById(id); 
  //a url to post comments to
  this.commentURL = commentURL?commentURL:'/comments/post_comment/'; 
  //a url to post replies to
  this.replyURL = replyURL?replyURL:'/comments/post_reply/';
  //a url that returns a JSON list of comments  
  this.getCommentsURL = getCommentsURL?getCommentsURL:'/comments/get_comments/'; 
  //the text to display in the comment text box
  this.commentText = commentText?commentText:'Your comment goes here.';
  //the object being commented on: {'type':string, 'id':integer}
  this.obj = null;                       
  //a list of comments 
  this.comments = [];                     
}


//Sets the target object of the comment widget and fetches comments from the server.
//A target object is at least {'type':string, 'id':integer}.
//For example, the target object might be {'type':'blogpost', 'id': 8}.
//Target objects are intended to potentially have other fields as well, 
//when the objects are being passed between Javascript widgets.
CommentWidget.prototype.select = function(obj) {
  this.obj = obj;
  this.getComments();
}


//displays the comment button and comments
CommentWidget.prototype.refresh = function() {
  clearDiv(this.div)
  this.div.appendChild(this.commentButtonHTML());
  if (this.comments.length > 0) { 
    this.div.appendChild(this.commentsHTML());  
  }
}


//displays the comment form when the comment button is pressed
CommentWidget.prototype.displayCommentForm = function() {  
  clearDiv(this.div)
  this.div.appendChild(this.commentFormHTML());
  if (this.comments.length > 0) { 
    this.div.appendChild(this.commentsHTML());   
  }
}


//returns the HTML for the button that reveals the comment form
CommentWidget.prototype.commentButtonHTML = function() {
  var input = document.createElement('input');
  input.type = "button";
  input.value = "Comment";
  var self = this;
  input.onclick = function () { self.displayCommentForm() };
  var p = document.createElement('p');
  p.appendChild(input);
  return p;
}  


//returns the HTML for the commenting form
CommentWidget.prototype.commentFormHTML = function() {
  var form = document.createElement('form');
  var textarea = document.createElement('textarea');
  textarea.onclick = expandCommentBox;
  textarea.name = "comment";
  textarea.value = this.commentText;
  textarea.className = 'commentText'
  form.appendChild(textarea);
  var input = document.createElement('input');
  input.type = 'button';
  var self = this
  input.onclick = function() { self.postComment(form) };
  input.value = "Submit";
  form.appendChild(input);
  input = document.createElement('input');
  input.type = 'button';
  input.onclick = function() { self.refresh() };
  input.value = "Cancel";
  form.appendChild(input);
  return form;
}


//returns the HTML for the tree of comments
CommentWidget.prototype.commentsHTML = function() {
  //children[0] is a list of comments with no parent
  //chidlren[i] is a list of comments whose parent comment id is i
  var children =  [];
  children[0] = [];
  for (var i = 0; i < this.comments.length; i++) {
    comment = this.comments[i];
    //if the comment has no parent, append it to the no parents list
    if (comment.parent == null){
      children[0].push(comment);
    }
    //if a list already exists for the parent, append the comment to that list
    else if (children[comment.parent]){       
      children[comment.parent].push(comment);
    }
    //otherwise, create a list of comments for that parent and append the comment
    else{  
      children[comment.parent] = new Array();
      children[comment.parent].push(comment); 
    }          
  }
  var commentHTML = document.createElement('div');
  commentHTML.appendChild(this.createCommentHTML(children[0], children));
  return commentHTML
}


//recursive function to create the HTML for the comments
CommentWidget.prototype.createCommentHTML = function(comments, children) {
  var ul = document.createElement('ul'); 
  for (var i = 0; i < comments.length; i++){
    var comment = comments[i];   
    var li = document.createElement('li');
    li.appendChild(document.createTextNode(comment.comment));
    li.appendChild(document.createElement('br'));
    if (comment['author']) {
      li.appendChild(document.createTextNode("by " + comment['author']));
    } else { 
      li.appendChild(document.createTextNode("by Anonymous"));
    }
    li.appendChild(document.createTextNode(' ' + comment['time_created']));
    var div = document.createElement('div');
    var a = document.createElement('a');
    a.replyID = comment.id;
    var self = this;
    a.onclick = function() { self.revealReplyBox(this) };
    a.className = 'jLink';
    a.appendChild(document.createTextNode("Reply"));
    div.appendChild(a);
    div.appendChild(document.createElement('br')); 
    div.appendChild(document.createElement('br')); 
    ul.appendChild(li);
    ul.appendChild(div);    
    //if the comment has children, then recurse
    if (children[comment.id] != null){
      var subul = this.createCommentHTML(children[comment.id], children);
      ul.appendChild(subul);
    }
  } 
  return ul;
} 


//reveals a reply form when a reply link is clicked
CommentWidget.prototype.revealReplyBox = function(replyA) {
  replyA.onclick = null;
  var p = document.createElement('p');
  var form = document.createElement('form');
  p.appendChild(form);
  form.replyId = replyA.replyID;
  var textarea = document.createElement('textarea');
  textarea.className = 'replyText'
  textarea.onclick = expandCommentBox;
  textarea.name = 'replyDiv' + replyA.replyID;
  textarea.value = "Your reply goes here.";  
  form.appendChild(textarea);
  var input = document.createElement('input');
  input.type = 'button'; 
  var self = this;
  input.onclick = function () { self.postReply(this.parentNode) } ;
  input.value = 'Reply';
  form.appendChild(input);
  input = document.createElement('input');
  input.type = 'button';
  input.onclick = function() { self.refresh() };
  input.value = "Cancel";
  form.appendChild(input);
  clearDiv(replyA)
  replyA.appendChild(p);
}


//posts the new comment, and then updates the page with the new comment
CommentWidget.prototype.postComment = function(form) {
  var commentURL = this.commentURL + this.obj.type + '/' + this.obj.id; 
  this.asyncRequest('POST', commentURL, form);
}


//posts the new reply comment, and then updates the page with the new comment list
CommentWidget.prototype.postReply = function(form) {
  var replyURL = this.replyURL + form.replyId; 
  this.asyncRequest('POST', replyURL, form);
}


//fetches comments from the server
CommentWidget.prototype.getComments = function() {
  var commentURL = this.getCommentsURL + this.obj.type + '/' + this.obj.id; 
  this.asyncRequest('GET', commentURL, null);
}


//initiates an XHR request
CommentWidget.prototype.asyncRequest = function(method, uri, form) {
  var o = createXhrObject()
  if(!o) { return null; } 
  o.open(method, uri, true);
  o.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
  var self = this;
  o.onreadystatechange =  function () {self.callback(o)};
  if (form) { 
    o.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');
    o.send(makePostData(form)); 
  } else {
    o.send(''); 
  }  
}


//after a comment is posted, this rewrites the comments on the page
CommentWidget.prototype.callback = function(o) {                  
  if (o.readyState != 4) { return }
  //turns the JSON string into a JavaScript object.
  var response_obj = eval('(' + o.responseText + ')');
  this.comments = response_obj.comments;
  this.refresh()
}


//creates a POST strng from a form
function makePostData (form) {
  var data = []
    for (var i = 0; i < form.elements.length; i++) {
    oElement  = form.elements[i];
    oName = oElement.name;
    oName = encodeURIComponent(oName) + '=';
    oValue = encodeURIComponent(oElement.value);
    data[i] = oName + oValue;
  }
  return data.join('&');
}


//a cross-browser-safe way to make an XHR request, cribbed from YUI
function createXhrObject() {
  var msxml_progid = ['Microsoft.XMLHTTP',
	    	      'MSXML2.XMLHTTP.3.0',
		      'MSXML2.XMLHTTP']
  var http;
  try {
    // Instantiates XMLHttpRequest in non-IE browsers and assigns to http.
    http = new XMLHttpRequest();
  } catch(e) {
    for(var i=0; i<msxml_progid.length; ++i){
      try {
        // Instantiates XMLHttpRequest for IE and assign to http
        http = new ActiveXObject(msxml_progid[i]);
	break;
      } catch(e2) {}
    }
  } finally {
    return http;
  }
}


//expands and clears the intro message from a comment or reply box when it's selected
function expandCommentBox() {
  this.className += ' clickedTextBox';
  this.value = "";
  this.onclick = null;
}


//a function to abbreviate the common task of clearing a div on the page
function clearDiv(div) {
  while(div.hasChildNodes()) {
    div.removeChild(div.firstChild);
  }
}
