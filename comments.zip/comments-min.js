
function CommentWidget(id,getCommentsURL,commentURL,replyURL,commentText){this.div=document.getElementById(id);this.commentURL=commentURL?commentURL:'/comments/post_comment/';this.replyURL=replyURL?replyURL:'/comments/post_reply/';this.getCommentsURL=getCommentsURL?getCommentsURL:'/comments/get_comments/';this.commentText=commentText?commentText:'Your comment goes here.';this.obj=null;this.comments=[];}
CommentWidget.prototype.select=function(obj){this.obj=obj;this.getComments();}
CommentWidget.prototype.refresh=function(){clearDiv(this.div)
this.div.appendChild(this.commentButtonHTML());if(this.comments.length>0){this.div.appendChild(this.commentsHTML());}}
CommentWidget.prototype.displayCommentForm=function(){clearDiv(this.div)
this.div.appendChild(this.commentFormHTML());if(this.comments.length>0){this.div.appendChild(this.commentsHTML());}}
CommentWidget.prototype.commentButtonHTML=function(){var input=document.createElement('input');input.type="button";input.value="Comment";var self=this;input.onclick=function(){self.displayCommentForm()};var p=document.createElement('p');p.appendChild(input);return p;}
CommentWidget.prototype.commentFormHTML=function(){var form=document.createElement('form');var textarea=document.createElement('textarea');textarea.onclick=expandCommentBox;textarea.name="comment";textarea.value=this.commentText;textarea.className='commentText'
form.appendChild(textarea);var input=document.createElement('input');input.type='button';var self=this
input.onclick=function(){self.postComment(form)};input.value="Submit";form.appendChild(input);input=document.createElement('input');input.type='button';input.onclick=function(){self.refresh()};input.value="Cancel";form.appendChild(input);return form;}
CommentWidget.prototype.commentsHTML=function(){var children=[];children[0]=[];for(var i=0;i<this.comments.length;i++){comment=this.comments[i];if(comment.parent==null){children[0].push(comment);}
else if(children[comment.parent]){children[comment.parent].push(comment);}
else{children[comment.parent]=new Array();children[comment.parent].push(comment);}}
var commentHTML=document.createElement('div');commentHTML.appendChild(this.createCommentHTML(children[0],children));return commentHTML}
CommentWidget.prototype.createCommentHTML=function(comments,children){var ul=document.createElement('ul');for(var i=0;i<comments.length;i++){var comment=comments[i];var li=document.createElement('li');li.appendChild(document.createTextNode(comment.comment));li.appendChild(document.createElement('br'));if(comment['author']){li.appendChild(document.createTextNode("by "+comment['author']));}else{li.appendChild(document.createTextNode("by Anonymous"));}
li.appendChild(document.createTextNode(' '+comment['time_created']));var div=document.createElement('div');var a=document.createElement('a');a.replyID=comment.id;var self=this;a.onclick=function(){self.revealReplyBox(this)};a.className='jLink';a.appendChild(document.createTextNode("Reply"));div.appendChild(a);div.appendChild(document.createElement('br'));div.appendChild(document.createElement('br'));ul.appendChild(li);ul.appendChild(div);if(children[comment.id]!=null){var subul=this.createCommentHTML(children[comment.id],children);ul.appendChild(subul);}}
return ul;}
CommentWidget.prototype.revealReplyBox=function(replyA){replyA.onclick=null;var p=document.createElement('p');var form=document.createElement('form');p.appendChild(form);form.replyId=replyA.replyID;var textarea=document.createElement('textarea');textarea.className='replyText'
textarea.onclick=expandCommentBox;textarea.name='replyDiv'+replyA.replyID;textarea.value="Your reply goes here.";form.appendChild(textarea);var input=document.createElement('input');input.type='button';var self=this;input.onclick=function(){self.postReply(this.parentNode)};input.value='Reply';form.appendChild(input);input=document.createElement('input');input.type='button';input.onclick=function(){self.refresh()};input.value="Cancel";form.appendChild(input);clearDiv(replyA)
replyA.appendChild(p);}
CommentWidget.prototype.postComment=function(form){var commentURL=this.commentURL+this.obj.type+'/'+this.obj.id;this.asyncRequest('POST',commentURL,form);}
CommentWidget.prototype.postReply=function(form){var replyURL=this.replyURL+form.replyId;this.asyncRequest('POST',replyURL,form);}
CommentWidget.prototype.getComments=function(){var commentURL=this.getCommentsURL+this.obj.type+'/'+this.obj.id;this.asyncRequest('GET',commentURL,null);}
CommentWidget.prototype.asyncRequest=function(method,uri,form){var o=createXhrObject()
if(!o){return null;}
o.open(method,uri,true);o.setRequestHeader('X-Requested-With','XMLHttpRequest');var self=this;o.onreadystatechange=function(){self.callback(o)};if(form){o.setRequestHeader('Content-Type','application/x-www-form-urlencoded; charset=UTF-8');o.send(makePostData(form));}else{o.send('');}}
CommentWidget.prototype.callback=function(o){if(o.readyState!=4){return}
var response_obj=eval('('+o.responseText+')');this.comments=response_obj.comments;this.refresh()}
function makePostData(form){var data=[]
for(var i=0;i<form.elements.length;i++){oElement=form.elements[i];oName=oElement.name;oName=encodeURIComponent(oName)+'=';oValue=encodeURIComponent(oElement.value);data[i]=oName+oValue;}
return data.join('&');}
function createXhrObject(){var msxml_progid=['Microsoft.XMLHTTP','MSXML2.XMLHTTP.3.0','MSXML2.XMLHTTP']
var http;try{http=new XMLHttpRequest();}catch(e){for(var i=0;i<msxml_progid.length;++i){try{http=new ActiveXObject(msxml_progid[i]);break;}catch(e2){}}}finally{return http;}}
function expandCommentBox(){this.className+=' clickedTextBox';this.value="";this.onclick=null;}
function clearDiv(div){while(div.hasChildNodes()){div.removeChild(div.firstChild);}}
